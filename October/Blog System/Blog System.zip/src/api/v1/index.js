const express = require('express');
const authRoutes = require('../../modules/v1/auth/routes/auth.routes');
const blogRoutes = require('../../modules/v1/blog/routes/blog.routes');
const userRoutes = require('../../modules/v1/user/routes/user.routes');
const categoryRoutes = require('../../modules/v1/category/routes/category.routes');
const cartRoute = require('../../modules/v1/cart/routes/cart.routes');
const orderRoute = require('../../modules/v1/order/routes/order.routes');

module.exports = () => {
    const app = express.Router()
    authRoutes(app)
    blogRoutes(app)
    userRoutes(app)
    // productRoute(app)
    // cartRoute(app)
    // orderRoute(app)
    return app;
}