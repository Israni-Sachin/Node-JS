let options = {
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'sachinss@1234',
    database: 'blog_system'
}

module.exports = options